import json
from zipfile import ZipFile

import re

ontology = {
    "景点": {
        "名称": set(),
        "门票": set(),
        "游玩时间": set(),
        "评分": set(),
        "周边景点": set(),
        "周边餐馆": set(),
        "周边酒店": set(),
    },
    "餐馆": {
        "名称": set(),
        "推荐菜": set(),
        "人均消费": set(),
        "评分": set(),
        "周边景点": set(),
        "周边餐馆": set(),
        "周边酒店": set(),
    },
    "酒店": {
        "名称": set(),
        "酒店类型": set(),
        "酒店设施": set(),
        "价格": set(),
        "评分": set(),
        "周边景点": set(),
        "周边餐馆": set(),
        "周边酒店": set(),
    },
    "地铁": {
        "出发地": set(),
        "目的地": set(),
    },
    "出租": {
        "出发地": set(),
        "目的地": set(),
    },
    "append":{
        "地址": set(),
        "营业时间": set(),
        "评分": set(),
    }
}
oog_list=['\u200e','\xc7','\u2615','\ufe0f' ,'\xe7' ,'\u200d' ,'\u3e06' ,'\u2022','\u3711' ,'\u2795','\xa0' ]
error_word='*错误字符*'
if __name__ == '__main__':
    pattern = re.compile('. .+')
    for split in ['train', 'val', 'test']:
        print(split)
        #with ZipFile('data/CrossWoz/'+split+'.json.zip', 'r') as zipfile:
        with open(f'{split}.json', 'r') as f:
            data = json.load(f)

        for dialog in data.values():
            for turn in dialog['messages']:
                if turn['role'] == 'sys':
                    state = turn['sys_state_init']
                    for domain_name, domain in state.items():
                        for slot_name, value in domain.items():

                            if slot_name == 'selectedResults':
                                continue
                            else:
                                value = value.replace('\t', ' ').strip()
                                if not value:
                                    continue
                                values = ontology[domain_name][slot_name]
                                if slot_name in ['酒店设施', '推荐菜']:
                                    # deal with values contain bothering space like "早 餐 服 务   无 烟 房"
                                    if pattern.match(value):
                                        value = value.replace('   ', ';').replace(' ', '').replace(';', ' ')
                                    for v in value.split(' '):
                                        if v:
                                            for oog_word in oog_list:
                                                if oog_word in value:
                                                    v=v.replace(oog_word,error_word)
                                            values.add(v)
                                elif value and value not in values:
                                    # if ',' in value or '，' in value or ' ' in value:
                                        # print(value, slot_name)
                                    for oog_word in oog_list:
                                        if oog_word in value:
                                            value=value.replace(oog_word,error_word)
                                    values.add(value)
                if 'dialog_act' in turn:
                    acts = turn['dialog_act']
                    for act in acts:
                        domain_name=act[1] 
                        slot=act[2]
                        value=act[3]
                        if slot in ontology["append"]:
                            for oog_word in oog_list:
                                    if oog_word in value:
                                        value=value.replace(oog_word,error_word)
                            ontology["append"][slot].add(value)   
    for domain in ontology.values():
        for slot_name, values in domain.items():
            domain[slot_name] = list(values)

    with open('ontology.json', 'w') as f:
        json.dump(ontology, f, indent=4, ensure_ascii=False)
